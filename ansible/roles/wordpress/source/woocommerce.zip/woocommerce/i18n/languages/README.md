# WARNING! DO NOT PUT CUSTOM TRANSLATIONS HERE!

WooCommerce will delete all custom translations placed in this directory.

## Translating WooCommerce
Put your custom WooCommerce translations in your WordPress language directory, located at: WP_LANG_DIR . "/woocommerce/{$textdomain}-{$locale}.mo";

## Contributing your translating to WooCommerce
If you want to help translate WooCommerce, please visit our [translation page](https://www.transifex.com/projects/p/woocommerce/).